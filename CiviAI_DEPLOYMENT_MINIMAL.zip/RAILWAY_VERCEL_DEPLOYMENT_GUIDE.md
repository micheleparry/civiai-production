# Complete CiviAI Deployment Guide: Railway + Vercel

## Overview

This guide will deploy your complete CiviAI system with all interactive features working:

- **Railway**: Django backend with AI integrations, database, and APIs
- **Vercel**: React frontend with all interactive components
- **Full Integration**: Frontend and backend communicating seamlessly

## Architecture

```
┌─────────────────┐    API Calls    ┌─────────────────┐
│   Vercel        │ ──────────────► │   Railway       │
│   React Frontend│                 │   Django Backend│
│   - UI/UX       │ ◄────────────── │   - AI Features │
│   - Components  │    JSON Data    │   - Database    │
│   - Routing     │                 │   - APIs        │
└─────────────────┘                 └─────────────────┘
```

## Phase 1: Prepare Your Code for Deployment

### Step 1: Organize Your Project Structure

First, let's organize your existing CiviAI files into a deployment-ready structure:

```
civiai-deployment/
├── backend/                 # Django application
│   ├── civiai_project/     # Django project
│   ├── permitting/         # Main app
│   ├── requirements.txt    # Python dependencies
│   ├── railway.json        # Railway configuration
│   └── .env.example        # Environment variables template
├── frontend/               # React application  
│   ├── src/               # React source code
│   ├── package.json       # Node dependencies
│   ├── vite.config.js     # Build configuration
│   └── vercel.json        # Vercel configuration
└── README.md              # Deployment instructions
```

### Step 2: Backend Preparation (Django for Railway)

#### Create requirements.txt
```txt
django>=4.2.0
djangorestframework
django-cors-headers
anthropic
openai
python-decouple
psycopg2-binary
gunicorn
whitenoise
django-environ
requests
```

#### Create railway.json
```json
{
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "python manage.py migrate && gunicorn civiai_project.wsgi",
    "healthcheckPath": "/api/health/"
  }
}
```

#### Update Django Settings for Production
```python
# settings.py additions for Railway deployment
import os
from decouple import config

# Railway-specific settings
DEBUG = config('DEBUG', default=False, cast=bool)
ALLOWED_HOSTS = ['*']  # Railway will provide the domain

# Database configuration for Railway PostgreSQL
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': config('PGDATABASE'),
        'USER': config('PGUSER'), 
        'PASSWORD': config('PGPASSWORD'),
        'HOST': config('PGHOST'),
        'PORT': config('PGPORT', default=5432),
    }
}

# Static files configuration
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# CORS settings for Vercel frontend
CORS_ALLOWED_ORIGINS = [
    "https://your-app.vercel.app",  # Will update with actual Vercel URL
]
CORS_ALLOW_ALL_ORIGINS = True  # For development, restrict in production

# AI API Keys
ANTHROPIC_API_KEY = config('ANTHROPIC_API_KEY')
OPENAI_API_KEY = config('OPENAI_API_KEY')
```

### Step 3: Frontend Preparation (React for Vercel)

#### Update package.json
```json
{
  "name": "civiai-frontend",
  "version": "1.0.0",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.8.0",
    "axios": "^1.3.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^3.1.0",
    "vite": "^4.1.0"
  }
}
```

#### Create vercel.json
```json
{
  "version": 2,
  "builds": [
    {
      "src": "package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist"
      }
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "https://your-railway-app.railway.app/api/$1"
    },
    {
      "src": "/(.*)",
      "dest": "/index.html"
    }
  ]
}
```

#### Update vite.config.js
```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false
  },
  define: {
    'process.env.VITE_API_URL': JSON.stringify(process.env.VITE_API_URL || 'http://localhost:8000')
  }
})
```

## Phase 2: Deploy Backend to Railway

### Step 1: Create Railway Account and Project

1. **Go to [railway.app](https://railway.app)**
2. **Sign up with GitHub** (connects your repositories automatically)
3. **Click "New Project"**
4. **Select "Deploy from GitHub repo"**
5. **Choose your CiviAI repository**

### Step 2: Configure Railway Deployment

1. **Set Root Directory**: Point to your `backend` folder
2. **Add Environment Variables**:
   ```
   SECRET_KEY=your-django-secret-key-here
   DEBUG=False
   ANTHROPIC_API_KEY=your-claude-api-key
   OPENAI_API_KEY=your-openai-api-key
   ```

### Step 3: Add PostgreSQL Database

1. **In Railway dashboard, click "New"**
2. **Select "Database" → "PostgreSQL"**
3. **Railway automatically sets these environment variables**:
   - PGDATABASE
   - PGUSER
   - PGPASSWORD
   - PGHOST
   - PGPORT

### Step 4: Deploy and Test Backend

1. **Railway will automatically build and deploy**
2. **Check deployment logs for any errors**
3. **Test API endpoints**: `https://your-app.railway.app/api/health/`

## Phase 3: Deploy Frontend to Vercel

### Step 1: Create Vercel Account and Project

1. **Go to [vercel.com](https://vercel.com)**
2. **Sign up with GitHub**
3. **Click "New Project"**
4. **Import your CiviAI repository**

### Step 2: Configure Vercel Deployment

1. **Set Root Directory**: Point to your `frontend` folder
2. **Build Command**: `npm run build`
3. **Output Directory**: `dist`
4. **Install Command**: `npm install`

### Step 3: Add Environment Variables

In Vercel dashboard, add:
```
VITE_API_URL=https://your-railway-app.railway.app
```

### Step 4: Deploy and Test Frontend

1. **Vercel will build and deploy automatically**
2. **Test your React app**: `https://your-app.vercel.app`
3. **Verify all components load correctly**

## Phase 4: Connect Frontend and Backend

### Step 1: Update CORS Settings

In your Django backend, update the CORS settings with your actual Vercel URL:

```python
CORS_ALLOWED_ORIGINS = [
    "https://your-actual-app.vercel.app",
]
```

### Step 2: Update API Configuration

In your React frontend, ensure API calls use the Railway backend:

```javascript
// api.js or similar
const API_BASE_URL = process.env.VITE_API_URL || 'https://your-railway-app.railway.app';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});
```

### Step 3: Test Full Integration

1. **Visit your Vercel frontend**
2. **Test AI assistant features**
3. **Try permit wizard functionality**
4. **Verify database operations work**
5. **Check compliance checking features**

## Expected Results

After successful deployment, you'll have:

✅ **Live CiviAI Platform**: Accessible via your Vercel URL
✅ **AI Features Working**: Claude integration for planning assistance
✅ **Database Integration**: PostgreSQL storing applications and data
✅ **Real-time Compliance**: Oregon statewide goals checking
✅ **Admin Dashboard**: City manager insights and analytics
✅ **User Authentication**: Login and role management
✅ **Document Processing**: AI-powered document analysis
✅ **Permit Wizard**: Step-by-step application guidance

## Troubleshooting Common Issues

### Backend Issues (Railway)

**Build Fails**:
- Check requirements.txt has all dependencies
- Verify Python version compatibility
- Check Railway build logs for specific errors

**Database Connection Fails**:
- Ensure PostgreSQL service is running
- Verify environment variables are set
- Check database credentials

**API Not Accessible**:
- Verify CORS settings allow frontend domain
- Check Railway service is running
- Test API endpoints directly

### Frontend Issues (Vercel)

**Build Fails**:
- Check package.json has correct scripts
- Verify all dependencies are listed
- Check Vercel build logs

**API Calls Fail**:
- Verify VITE_API_URL environment variable
- Check CORS settings on backend
- Test API endpoints in browser network tab

**Routing Issues**:
- Ensure vercel.json has correct routing rules
- Check React Router configuration
- Verify all routes are properly defined

## Monitoring and Maintenance

### Railway Backend Monitoring
- Check Railway dashboard for service health
- Monitor database usage and performance
- Review application logs for errors

### Vercel Frontend Monitoring
- Use Vercel analytics for performance insights
- Monitor build times and deployment success
- Check for JavaScript errors in browser console

### Regular Updates
- Keep dependencies updated
- Monitor AI API usage and costs
- Backup database regularly
- Test new features in staging environment

## Cost Estimation

### Railway (Backend + Database)
- **Hobby Plan**: $5/month
- **Pro Plan**: $20/month (for production)
- **Database**: Included in plan

### Vercel (Frontend)
- **Hobby Plan**: Free for personal projects
- **Pro Plan**: $20/month (for commercial use)

### AI APIs
- **Anthropic Claude**: Pay per use (~$0.01-0.10 per request)
- **OpenAI**: Pay per use (~$0.002-0.02 per request)

**Total Monthly Cost**: $25-50 for a professional deployment

This deployment strategy gives you a scalable, professional CiviAI platform that can handle real municipal workloads!

