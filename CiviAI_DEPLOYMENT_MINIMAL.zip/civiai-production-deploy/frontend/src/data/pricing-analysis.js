// CiviAI Pricing and ROI Analysis Data

export const cityCategories = [
  {
    id: 'small',
    name: 'Small Cities',
    population: 'Under 5,000',
    avgPermits: 50,
    avgStaffCost: 65000,
    avgReviewTime: 14, // days
    avgBacklog: 25,
    plan: 'starter'
  },
  {
    id: 'medium',
    name: 'Mid-Size Cities',
    population: '5,000 - 25,000',
    avgPermits: 200,
    avgStaffCost: 75000,
    avgReviewTime: 21,
    avgBacklog: 75,
    plan: 'professional'
  },
  {
    id: 'large',
    name: 'Large Cities',
    population: '25,000+',
    avgPermits: 800,
    avgStaffCost: 85000,
    avgReviewTime: 28,
    avgBacklog: 200,
    plan: 'enterprise'
  }
]

export const pricingTiers = [
  {
    id: 'starter',
    name: 'Starter',
    monthlyPrice: 299,
    annualPrice: 2988, // 17% discount
    setup: 500,
    features: {
      permits: 100,
      aiAssistant: 'basic',
      compliance: 'standard',
      support: 'email',
      dashboard: 'basic',
      customBranding: false,
      apiAccess: false,
      training: '2 hours'
    },
    targetCities: 'Under 5,000 population',
    roi: {
      timeReduction: 60, // percentage
      staffSavings: 0.3, // FTE
      complianceImprovement: 25, // percentage
      paybackMonths: 4
    }
  },
  {
    id: 'professional',
    name: 'Professional',
    monthlyPrice: 599,
    annualPrice: 5988, // 17% discount
    setup: 1000,
    features: {
      permits: 500,
      aiAssistant: 'advanced',
      compliance: 'comprehensive',
      support: 'priority',
      dashboard: 'advanced',
      customBranding: true,
      apiAccess: 'limited',
      training: '8 hours'
    },
    targetCities: '5,000 - 25,000 population',
    roi: {
      timeReduction: 75,
      staffSavings: 0.8,
      complianceImprovement: 40,
      paybackMonths: 3
    }
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    monthlyPrice: 1299,
    annualPrice: 12990, // 17% discount
    setup: 2500,
    features: {
      permits: 'unlimited',
      aiAssistant: 'custom',
      compliance: 'expert',
      support: 'dedicated',
      dashboard: 'executive',
      customBranding: true,
      apiAccess: 'full',
      training: '20 hours'
    },
    targetCities: '25,000+ population',
    roi: {
      timeReduction: 85,
      staffSavings: 1.5,
      complianceImprovement: 60,
      paybackMonths: 2
    }
  }
]

export const roiCalculations = {
  calculateAnnualSavings: (cityCategory, pricingTier) => {
    const category = cityCategories.find(c => c.id === cityCategory)
    const tier = pricingTiers.find(t => t.id === pricingTier)
    
    if (!category || !tier) return null

    // Staff time savings
    const staffSavings = tier.roi.staffSavings * category.avgStaffCost
    
    // Reduced review time value (faster permits = economic development)
    const timeValue = category.avgPermits * 12 * 150 * (tier.roi.timeReduction / 100)
    
    // Compliance cost avoidance (avoiding violations, appeals, legal costs)
    const complianceSavings = category.avgPermits * 12 * 75 * (tier.roi.complianceImprovement / 100)
    
    // Reduced backlog value
    const backlogValue = category.avgBacklog * 200 * (tier.roi.timeReduction / 100)
    
    return {
      staffSavings,
      timeValue,
      complianceSavings,
      backlogValue,
      totalAnnualSavings: staffSavings + timeValue + complianceSavings + backlogValue,
      annualCost: tier.annualPrice + tier.setup,
      netBenefit: (staffSavings + timeValue + complianceSavings + backlogValue) - (tier.annualPrice + tier.setup),
      roiPercentage: ((staffSavings + timeValue + complianceSavings + backlogValue) / (tier.annualPrice + tier.setup) - 1) * 100
    }
  }
}

export const competitorAnalysis = [
  {
    name: 'Traditional Manual Process',
    cost: 0,
    timeReduction: 0,
    complianceAccuracy: 65,
    staffRequired: 2.5,
    issues: ['High error rate', 'Inconsistent decisions', 'Long review times', 'Staff burnout']
  },
  {
    name: 'Basic Permit Software',
    cost: 150,
    timeReduction: 20,
    complianceAccuracy: 75,
    staffRequired: 2.2,
    issues: ['Limited AI', 'No compliance checking', 'Manual review required']
  },
  {
    name: 'CiviAI',
    cost: 599, // Professional plan
    timeReduction: 75,
    complianceAccuracy: 92,
    staffRequired: 1.2,
    advantages: ['AI-powered assistance', 'Real-time compliance', 'Statewide goals integration', 'Document analysis']
  }
]

export const implementationTimeline = [
  {
    phase: 'Setup & Configuration',
    duration: '1-2 weeks',
    activities: ['System setup', 'Data migration', 'Staff training', 'Initial configuration']
  },
  {
    phase: 'Pilot Testing',
    duration: '2-4 weeks', 
    activities: ['Process 10-20 test permits', 'Staff feedback', 'System refinement', 'Workflow optimization']
  },
  {
    phase: 'Full Deployment',
    duration: '1-2 weeks',
    activities: ['Go-live', 'Monitor performance', 'Address issues', 'Optimize workflows']
  },
  {
    phase: 'Optimization',
    duration: 'Ongoing',
    activities: ['Performance monitoring', 'Feature updates', 'Advanced training', 'Expansion planning']
  }
]

export const successMetrics = [
  {
    metric: 'Average Review Time',
    before: '14-28 days',
    after: '2-7 days',
    improvement: '75-85%'
  },
  {
    metric: 'Compliance Accuracy',
    before: '65-75%',
    after: '92-98%',
    improvement: '25-30%'
  },
  {
    metric: 'Staff Productivity',
    before: '50 permits/month/FTE',
    after: '150 permits/month/FTE',
    improvement: '200%'
  },
  {
    metric: 'Applicant Satisfaction',
    before: '6.2/10',
    after: '8.9/10',
    improvement: '44%'
  },
  {
    metric: 'Department Efficiency',
    before: '2.5 FTE required',
    after: '1.2 FTE required',
    improvement: '52% reduction'
  }
]

