import axios from 'axios';

// API configuration for CiviAI backend
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true, // Include cookies for session authentication
});

// Request interceptor to add authentication token if available
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle common errors
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized access
      localStorage.removeItem('authToken');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// API endpoints
export const endpoints = {
  // Authentication
  login: '/api/auth/login/',
  logout: '/api/auth/logout/',
  register: '/api/auth/register/',
  
  // Permits
  permits: '/api/permits/',
  permitTypes: '/api/permit-types/',
  
  // Properties
  properties: '/api/properties/',
  propertyLookup: '/api/properties/lookup/',
  
  // AI Assistant
  aiChat: '/api/ai/chat/',
  aiAnalyze: '/api/ai/analyze/',
  
  // Compliance
  complianceCheck: '/api/compliance/check/',
  oregonGoals: '/api/compliance/oregon-goals/',
  
  // Applications
  applications: '/api/applications/',
  applicationSubmit: '/api/applications/submit/',
  
  // Admin
  dashboard: '/api/admin/dashboard/',
  analytics: '/api/admin/analytics/',
  
  // Health check
  health: '/api/health/',
};

export default api;

