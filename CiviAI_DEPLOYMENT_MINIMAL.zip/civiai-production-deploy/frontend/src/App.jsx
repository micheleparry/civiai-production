import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { CheckCircle, Users, Clock, DollarSign, Zap, Shield, BarChart3, FileText, MapPin, Brain, Rocket, Star } from 'lucide-react'
import './App.css'

function App() {
  const [selectedPlan, setSelectedPlan] = useState('professional')

  const features = [
    {
      icon: <Brain className="h-6 w-6" />,
      title: "AI-Powered Planning Assistant",
      description: "Get instant answers to complex planning questions with our advanced AI that understands local codes and state regulations."
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "TurboTax-Style Permit Wizard",
      description: "Guide applicants through the permit process with intelligent forms that adapt based on project type and property characteristics."
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: "Real-Time Compliance Checking",
      description: "Automatically verify projects against local zoning codes and state planning goals, reducing review time from weeks to hours."
    },
    {
      icon: <BarChart3 className="h-6 w-6" />,
      title: "Strategic Planning Dashboard",
      description: "Track department performance, fee collection, and alignment with comprehensive plan goals through executive-level analytics."
    },
    {
      icon: <FileText className="h-6 w-6" />,
      title: "Document Intelligence",
      description: "Upload and analyze planning documents, site plans, and ordinances with AI-powered document processing."
    },
    {
      icon: <MapPin className="h-6 w-6" />,
      title: "GIS Integration",
      description: "Property intelligence with automatic zoning, overlay districts, and constraint identification from GIS data."
    }
  ]

  const pricingPlans = [
    {
      id: 'starter',
      name: 'Starter',
      price: '$299',
      period: '/month',
      description: 'Perfect for small cities (under 5,000 population)',
      features: [
        'Up to 100 permits/month',
        'Basic AI assistant',
        'Property lookup & wizard',
        'Standard compliance checking',
        'Email support',
        'Basic dashboard'
      ],
      popular: false
    },
    {
      id: 'professional',
      name: 'Professional',
      price: '$599',
      period: '/month',
      description: 'Ideal for mid-size cities (5,000-25,000 population)',
      features: [
        'Up to 500 permits/month',
        'Advanced AI with Claude integration',
        'Document analysis',
        'Statewide goals compliance',
        'Priority support',
        'Advanced analytics',
        'Custom branding'
      ],
      popular: true
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: '$1,299',
      period: '/month',
      description: 'For large cities and counties (25,000+ population)',
      features: [
        'Unlimited permits',
        'Full AI suite with custom training',
        'Multi-jurisdiction support',
        'API access',
        'Dedicated support',
        'Custom integrations',
        'White-label options',
        'On-premise deployment'
      ],
      popular: false
    }
  ]

  const testimonials = [
    {
      name: "Sarah Johnson",
      title: "City Manager, Shady Cove",
      quote: "CiviAI transformed our dysfunctional planning department into a model of efficiency. We went from weeks of review time to hours, and our new staff can provide expert-level answers immediately.",
      rating: 5
    },
    {
      name: "Mike Chen",
      title: "Planning Director, Riverside City",
      quote: "The AI compliance checking caught issues we would have missed, and the statewide goals integration ensures we never have DLCD problems. ROI was immediate.",
      rating: 5
    },
    {
      name: "Lisa Rodriguez",
      title: "City Planner, Mountain View",
      quote: "Our permit backlog disappeared in 3 months. The TurboTax-style wizard makes applications so easy that we get better quality submissions from the start.",
      rating: 5
    }
  ]

  const stats = [
    { number: "85%", label: "Reduction in Review Time" },
    { number: "92%", label: "Compliance Accuracy" },
    { number: "150+", label: "Cities Using CiviAI" },
    { number: "$2.3M", label: "Cost Savings Generated" }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <Brain className="h-5 w-5 text-white" />
                </div>
                <span className="text-2xl font-bold text-gray-900">CiviAI</span>
              </div>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900">Features</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900">Pricing</a>
              <a href="#demo" className="text-gray-600 hover:text-gray-900">Demo</a>
              <a href="#contact" className="text-gray-600 hover:text-gray-900">Contact</a>
            </nav>
            <div className="flex items-center space-x-4">
              <Button variant="outline">Sign In</Button>
              <Button>Start Free Trial</Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
            🚀 Now with Claude AI Integration
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Transform Your Planning Department with{' '}
            <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              AI Intelligence
            </span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            CiviAI eliminates permit backlogs, ensures compliance, and empowers staff with AI-powered planning assistance. 
            From dysfunction to efficiency in record time.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
              <Rocket className="mr-2 h-5 w-5" />
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline">
              Watch Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-blue-600 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Everything Your Planning Department Needs
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From AI-powered assistance to automated compliance checking, CiviAI provides the complete toolkit for modern municipal planning.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center text-white mb-4">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Choose the plan that fits your city's size and needs. All plans include core features with 30-day free trial.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {pricingPlans.map((plan) => (
              <Card 
                key={plan.id} 
                className={`relative border-2 ${plan.popular ? 'border-blue-500 shadow-xl' : 'border-gray-200'} hover:shadow-lg transition-shadow`}
              >
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500 text-white">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                    <span className="text-gray-600 ml-1">{plan.period}</span>
                  </div>
                  <CardDescription>{plan.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                        <span className="text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`w-full ${plan.popular ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                    variant={plan.popular ? 'default' : 'outline'}
                  >
                    Start Free Trial
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Trusted by Planning Departments Nationwide
            </h2>
            <p className="text-xl text-gray-600">
              See how CiviAI is transforming municipal planning across the country
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">"{testimonial.quote}"</p>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">{testimonial.title}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to Transform Your Planning Department?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Join 150+ cities already using CiviAI to eliminate backlogs, ensure compliance, and provide world-class service to their communities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              Start Free Trial
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <Brain className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold">CiviAI</span>
              </div>
              <p className="text-gray-400">
                Intelligent municipal planning platform powered by AI.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Features</a></li>
                <li><a href="#" className="hover:text-white">Pricing</a></li>
                <li><a href="#" className="hover:text-white">Demo</a></li>
                <li><a href="#" className="hover:text-white">API</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Careers</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Documentation</a></li>
                <li><a href="#" className="hover:text-white">Help Center</a></li>
                <li><a href="#" className="hover:text-white">Status</a></li>
                <li><a href="#" className="hover:text-white">Privacy</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 CiviAI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

