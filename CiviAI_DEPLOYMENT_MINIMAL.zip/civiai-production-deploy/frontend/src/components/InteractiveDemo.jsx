import { useState, useEffect } from 'react'

const InteractiveDemo = () => {
  const [currentStep, setCurrentStep] = useState(0)
  const [demoData, setDemoData] = useState({
    address: '',
    permitType: '',
    projectDetails: '',
    fee: 0,
    complianceResults: []
  })

  const demoSteps = [
    {
      title: "Property Lookup",
      description: "Start by entering a property address",
      component: "PropertyLookup"
    },
    {
      title: "Permit Selection", 
      description: "Choose your permit type",
      component: "PermitSelection"
    },
    {
      title: "Project Details",
      description: "Describe your project",
      component: "ProjectDetails"
    },
    {
      title: "AI Compliance Check",
      description: "Real-time compliance analysis",
      component: "ComplianceCheck"
    },
    {
      title: "Results & Approval",
      description: "Get your permit decision",
      component: "Results"
    }
  ]

  const PropertyLookup = () => (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold mb-4">Property Lookup</h3>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Property Address
          </label>
          <input
            type="text"
            value={demoData.address}
            onChange={(e) => setDemoData({...demoData, address: e.target.value})}
            placeholder="123 Main Street, Shady Cove, OR"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <button
          onClick={() => {
            setDemoData({
              ...demoData, 
              address: "123 Main Street, Shady Cove, OR"
            })
            setTimeout(() => setCurrentStep(1), 1000)
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
        >
          Find Property
        </button>
        {demoData.address && (
          <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-md">
            <h4 className="font-semibold text-green-800">Property Found!</h4>
            <div className="text-sm text-green-700 mt-2">
              <p><strong>Zoning:</strong> R-1 (Single Family Residential)</p>
              <p><strong>Tax Lot:</strong> 36-4W-33-1000</p>
              <p><strong>Overlays:</strong> Floodplain, Riparian</p>
              <p><strong>Lot Size:</strong> 0.25 acres</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )

  const PermitSelection = () => (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold mb-4">Select Permit Type</h3>
      <div className="grid grid-cols-2 gap-4">
        {[
          { type: "Deck Addition", fee: 75, description: "Residential deck construction" },
          { type: "Home Addition", fee: 150, description: "Room addition or expansion" },
          { type: "Fence Installation", fee: 50, description: "Property boundary fencing" },
          { type: "Shed Construction", fee: 65, description: "Accessory structure" }
        ].map((permit) => (
          <button
            key={permit.type}
            onClick={() => {
              setDemoData({...demoData, permitType: permit.type, fee: permit.fee})
              setTimeout(() => setCurrentStep(2), 800)
            }}
            className={`p-4 border rounded-lg text-left hover:bg-blue-50 transition-colors ${
              demoData.permitType === permit.type ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
            }`}
          >
            <h4 className="font-semibold">{permit.type}</h4>
            <p className="text-sm text-gray-600">{permit.description}</p>
            <p className="text-sm font-medium text-green-600">${permit.fee}</p>
          </button>
        ))}
      </div>
    </div>
  )

  const ProjectDetails = () => (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold mb-4">Project Details</h3>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Project Description
          </label>
          <textarea
            value={demoData.projectDetails}
            onChange={(e) => setDemoData({...demoData, projectDetails: e.target.value})}
            placeholder="Building a 12x16 foot deck attached to the rear of the house..."
            rows={4}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Square Footage
            </label>
            <input
              type="number"
              placeholder="192"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Height (feet)
            </label>
            <input
              type="number"
              placeholder="8"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <button
          onClick={() => {
            setDemoData({
              ...demoData, 
              projectDetails: "Building a 12x16 foot deck attached to the rear of the house for outdoor entertaining"
            })
            setTimeout(() => setCurrentStep(3), 1000)
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
        >
          Continue to Compliance Check
        </button>
      </div>
    </div>
  )

  const ComplianceCheck = () => {
    const [checking, setChecking] = useState(true)
    const [results, setResults] = useState([])

    useEffect(() => {
      if (checking) {
        setTimeout(() => {
          setResults([
            { rule: "Setback Requirements", status: "pass", details: "Rear setback: 15 ft (required: 10 ft)" },
            { rule: "Height Restrictions", status: "pass", details: "Structure height: 8 ft (max: 15 ft)" },
            { rule: "Lot Coverage", status: "pass", details: "Coverage: 22% (max: 35%)" },
            { rule: "Floodplain Compliance", status: "warning", details: "Elevated construction recommended" },
            { rule: "Riparian Buffer", status: "pass", details: "50 ft from water (required: 25 ft)" }
          ])
          setDemoData({...demoData, complianceResults: results})
          setChecking(false)
          setTimeout(() => setCurrentStep(4), 2000)
        }, 3000)
      }
    }, [checking])

    return (
      <div className="bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-xl font-semibold mb-4">AI Compliance Analysis</h3>
        {checking ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Analyzing compliance with local codes and Oregon statewide goals...</p>
          </div>
        ) : (
          <div className="space-y-3">
            {results.map((result, index) => (
              <div key={index} className={`p-3 rounded-md border ${
                result.status === 'pass' ? 'bg-green-50 border-green-200' :
                result.status === 'warning' ? 'bg-yellow-50 border-yellow-200' :
                'bg-red-50 border-red-200'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="font-medium">{result.rule}</span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    result.status === 'pass' ? 'bg-green-100 text-green-800' :
                    result.status === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }`}>
                    {result.status === 'pass' ? '✓ PASS' : 
                     result.status === 'warning' ? '⚠ WARNING' : '✗ FAIL'}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mt-1">{result.details}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    )
  }

  const Results = () => (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold mb-4">Permit Decision</h3>
      <div className="text-center py-6">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h4 className="text-2xl font-bold text-green-600 mb-2">APPROVED</h4>
        <p className="text-gray-600 mb-6">Your deck addition permit has been approved!</p>
        
        <div className="bg-gray-50 p-4 rounded-lg mb-6">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Permit Type:</span>
              <p>{demoData.permitType}</p>
            </div>
            <div>
              <span className="font-medium">Fee:</span>
              <p>${demoData.fee}</p>
            </div>
            <div>
              <span className="font-medium">Permit #:</span>
              <p>SC-2024-0123</p>
            </div>
            <div>
              <span className="font-medium">Valid Until:</span>
              <p>July 17, 2025</p>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors">
            Download Permit
          </button>
          <button className="w-full bg-gray-200 text-gray-800 py-2 px-4 rounded-md hover:bg-gray-300 transition-colors">
            Schedule Inspection
          </button>
        </div>
      </div>
    </div>
  )

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 0: return <PropertyLookup />
      case 1: return <PermitSelection />
      case 2: return <ProjectDetails />
      case 3: return <ComplianceCheck />
      case 4: return <Results />
      default: return <PropertyLookup />
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-center mb-4">Interactive CiviAI Demo</h2>
        <p className="text-gray-600 text-center">Experience the TurboTax-style permit process</p>
      </div>

      {/* Progress Steps */}
      <div className="mb-8">
        <div className="flex items-center justify-between">
          {demoSteps.map((step, index) => (
            <div key={index} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                index <= currentStep ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'
              }`}>
                {index + 1}
              </div>
              <div className="ml-2 hidden sm:block">
                <p className={`text-sm font-medium ${
                  index <= currentStep ? 'text-blue-600' : 'text-gray-500'
                }`}>
                  {step.title}
                </p>
              </div>
              {index < demoSteps.length - 1 && (
                <div className={`w-12 h-0.5 mx-4 ${
                  index < currentStep ? 'bg-blue-600' : 'bg-gray-200'
                }`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Current Step Content */}
      <div className="mb-8">
        {renderCurrentStep()}
      </div>

      {/* Navigation */}
      <div className="flex justify-between">
        <button
          onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
          disabled={currentStep === 0}
          className="px-4 py-2 text-gray-600 hover:text-gray-800 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          ← Previous
        </button>
        <button
          onClick={() => setCurrentStep(0)}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
        >
          Restart Demo
        </button>
        <button
          onClick={() => setCurrentStep(Math.min(demoSteps.length - 1, currentStep + 1))}
          disabled={currentStep === demoSteps.length - 1}
          className="px-4 py-2 text-blue-600 hover:text-blue-800 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Next →
        </button>
      </div>

      {/* Demo Features Highlight */}
      <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="text-center p-4">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </div>
          <h3 className="font-semibold mb-2">Lightning Fast</h3>
          <p className="text-sm text-gray-600">Complete permit applications in minutes, not hours</p>
        </div>
        <div className="text-center p-4">
          <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
            <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="font-semibold mb-2">AI-Powered</h3>
          <p className="text-sm text-gray-600">Real-time compliance checking with 92% accuracy</p>
        </div>
        <div className="text-center p-4">
          <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
            <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
            </svg>
          </div>
          <h3 className="font-semibold mb-2">Comprehensive</h3>
          <p className="text-sm text-gray-600">Local codes + Oregon statewide goals in one system</p>
        </div>
      </div>
    </div>
  )
}

export default InteractiveDemo

