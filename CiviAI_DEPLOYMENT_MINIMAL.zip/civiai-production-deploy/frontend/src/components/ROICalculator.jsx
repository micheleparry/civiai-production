import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Calculator, TrendingUp, Clock, Users, DollarSign, CheckCircle } from 'lucide-react'
import { cityCategories, pricingTiers, roiCalculations } from '../data/pricing-analysis.js'

export default function ROICalculator() {
  const [selectedCity, setSelectedCity] = useState('medium')
  const [selectedPlan, setSelectedPlan] = useState('professional')
  const [roiData, setRoiData] = useState(null)

  useEffect(() => {
    if (selectedCity && selectedPlan) {
      const calculation = roiCalculations.calculateAnnualSavings(selectedCity, selectedPlan)
      setRoiData(calculation)
    }
  }, [selectedCity, selectedPlan])

  const cityCategory = cityCategories.find(c => c.id === selectedCity)
  const pricingTier = pricingTiers.find(t => t.id === selectedPlan)

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const formatPercentage = (value) => {
    return `${Math.round(value)}%`
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Calculate Your ROI with CiviAI
        </h2>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          See exactly how much your city can save with intelligent planning automation. 
          Our calculator uses real data from 150+ cities already using CiviAI.
        </p>
      </div>

      {/* Input Controls */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Select Your City Size
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger>
                <SelectValue placeholder="Choose city category" />
              </SelectTrigger>
              <SelectContent>
                {cityCategories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name} ({category.population})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {cityCategory && (
              <div className="mt-4 space-y-2 text-sm text-gray-600">
                <div>Average permits/month: {cityCategory.avgPermits}</div>
                <div>Current review time: {cityCategory.avgReviewTime} days</div>
                <div>Current backlog: {cityCategory.avgBacklog} permits</div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calculator className="h-5 w-5 mr-2" />
              Select CiviAI Plan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={selectedPlan} onValueChange={setSelectedPlan}>
              <SelectTrigger>
                <SelectValue placeholder="Choose pricing plan" />
              </SelectTrigger>
              <SelectContent>
                {pricingTiers.map((tier) => (
                  <SelectItem key={tier.id} value={tier.id}>
                    {tier.name} - {formatCurrency(tier.monthlyPrice)}/month
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {pricingTier && (
              <div className="mt-4 space-y-2 text-sm text-gray-600">
                <div>Monthly cost: {formatCurrency(pricingTier.monthlyPrice)}</div>
                <div>Setup fee: {formatCurrency(pricingTier.setup)}</div>
                <div>Target: {pricingTier.targetCities}</div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ROI Results */}
      {roiData && (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid md:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-r from-green-50 to-green-100 border-green-200">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-green-600">Annual Savings</p>
                    <p className="text-2xl font-bold text-green-700">
                      {formatCurrency(roiData.totalAnnualSavings)}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-blue-50 to-blue-100 border-blue-200">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-600">ROI</p>
                    <p className="text-2xl font-bold text-blue-700">
                      {formatPercentage(roiData.roiPercentage)}
                    </p>
                  </div>
                  <Calculator className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-purple-600">Payback Period</p>
                    <p className="text-2xl font-bold text-purple-700">
                      {pricingTier.roi.paybackMonths} months
                    </p>
                  </div>
                  <Clock className="h-8 w-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-orange-50 to-orange-100 border-orange-200">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-orange-600">Net Benefit</p>
                    <p className="text-2xl font-bold text-orange-700">
                      {formatCurrency(roiData.netBenefit)}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle>Detailed Savings Breakdown</CardTitle>
              <CardDescription>
                See exactly where your savings come from with CiviAI implementation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Annual Savings</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Staff Time Savings</span>
                      <span className="font-semibold">{formatCurrency(roiData.staffSavings)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Faster Review Process</span>
                      <span className="font-semibold">{formatCurrency(roiData.timeValue)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Compliance Cost Avoidance</span>
                      <span className="font-semibold">{formatCurrency(roiData.complianceSavings)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Backlog Reduction Value</span>
                      <span className="font-semibold">{formatCurrency(roiData.backlogValue)}</span>
                    </div>
                    <div className="border-t pt-3">
                      <div className="flex justify-between items-center font-bold">
                        <span>Total Annual Savings</span>
                        <span className="text-green-600">{formatCurrency(roiData.totalAnnualSavings)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Annual Investment</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">CiviAI Subscription</span>
                      <span className="font-semibold">{formatCurrency(pricingTier.annualPrice)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Setup & Training</span>
                      <span className="font-semibold">{formatCurrency(pricingTier.setup)}</span>
                    </div>
                    <div className="border-t pt-3">
                      <div className="flex justify-between items-center font-bold">
                        <span>Total Annual Cost</span>
                        <span className="text-red-600">{formatCurrency(roiData.annualCost)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center mb-2">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                      <span className="font-semibold text-green-800">Net Annual Benefit</span>
                    </div>
                    <div className="text-2xl font-bold text-green-700">
                      {formatCurrency(roiData.netBenefit)}
                    </div>
                    <div className="text-sm text-green-600 mt-1">
                      {formatPercentage(roiData.roiPercentage)} return on investment
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Performance Improvements */}
          <Card>
            <CardHeader>
              <CardTitle>Performance Improvements</CardTitle>
              <CardDescription>
                Key metrics that improve with CiviAI implementation
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    {formatPercentage(pricingTier.roi.timeReduction)}
                  </div>
                  <div className="text-gray-600">Faster Review Time</div>
                  <div className="text-sm text-gray-500 mt-1">
                    From {cityCategory.avgReviewTime} days to {Math.round(cityCategory.avgReviewTime * (1 - pricingTier.roi.timeReduction / 100))} days
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {pricingTier.roi.staffSavings} FTE
                  </div>
                  <div className="text-gray-600">Staff Time Saved</div>
                  <div className="text-sm text-gray-500 mt-1">
                    Equivalent to {formatCurrency(pricingTier.roi.staffSavings * cityCategory.avgStaffCost)} annually
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-2">
                    {formatPercentage(pricingTier.roi.complianceImprovement)}
                  </div>
                  <div className="text-gray-600">Better Compliance</div>
                  <div className="text-sm text-gray-500 mt-1">
                    Fewer violations and appeals
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Call to Action */}
          <Card className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
            <CardContent className="pt-6">
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-4">
                  Ready to Save {formatCurrency(roiData.totalAnnualSavings)} Annually?
                </h3>
                <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
                  Join 150+ cities already using CiviAI to transform their planning departments. 
                  Start your free trial today and see results in weeks, not months.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                    Start Free Trial
                  </Button>
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                    Schedule Demo
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

